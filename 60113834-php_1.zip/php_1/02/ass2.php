
<html>
<style>
    .even {
        background: gray;
    }
    .head {
        background: black;
        color:white;
    }
    table {
        border: 1px;
        
    }
</style>

<body>
<table border=0>
    <thead>
    <tr class="head">
        
    </tr>
    </thead>


    </tbody>
</table>
    

</body>

</html>

<?php
echo "<html><body><table>\n\n";
$f = fopen("oscar.csv", "r");
// $binny= fgetcsv($f);
$i=0;

while (($line = fgetcsv($f)) !== false) {
        if($i==0){
            echo "<tr class='head'>";
            if($line == "Year1"){
                echo ($line)."year";
            }
        }else {
            echo "<tr class='even'>";
        }
        
        foreach ($line as $cell) {
                echo "<td >" . htmlspecialchars($cell) . "</td>";
        }
        echo "</tr >\n";
        $i++;
}
fclose($f);
echo "\n</table></body></html>"; 
?>