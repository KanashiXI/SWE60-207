<?php
    $file = fopen("input3.csv","r");

    while (true) {
        $line = fgetcsv($file);
        $Y = 0.5 * ($line[0]) * ($line[1]) * sin(floatval($line[2]));
        echo $Y;
        if(feof($file)) break;
    }
fclose($file);
    