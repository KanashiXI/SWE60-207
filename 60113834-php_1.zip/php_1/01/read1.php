<?php
$file = fopen("input1.csv","r");
// $header = fgetcsv($file);

while(true){
  $line = fgetcsv($file);
//    print_r($line);
  $sec = ($line[0] * 3600) + ($line[1] * 60) + $line[2];
  echo $sec;
  if(feof($file)) break;
}
fclose($file);
