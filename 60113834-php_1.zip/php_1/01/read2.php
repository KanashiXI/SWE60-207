<?php
    $file = fopen("input2.csv","r");

    while (true) {
        $line = fgetcsv($file);
        $y = 2 - ($line[0]) + 3 / 7 * ($line[0]) * ($line[0]) + log($line[0]); //y = 2-x + 3/7*x*x +log(x)
        echo $y;
        if(feof($file)) break;
    }
fclose($file);
    