<?php
$file = fopen("input4.csv","r");
// $header = fgetcsv($file);

while(true){
   $line = fgetcsv($file);
//    print_r($line);
   if($line[0]>46){
       echo "XL";
   } else if($line[0] >= 43){
       echo "L";
   }else if($line[0] >= 41){
    echo "M";
    }else if($line[0] >= 37){
        echo "S";
    }else echo "XS";
    echo "<br>";

   if(feof($file)) break;
}
fclose($file);

