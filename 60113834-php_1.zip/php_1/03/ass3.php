<?php
   abstract class BaseCSV{
    abstract public function showHeader();
    abstract public function showLine($id=null);
    abstract public function getRowByID($id);
    abstract public function getHeader();
    abstract public function getRows();
    abstract public function getNRows();
    abstract public  function searchItemByKey($fields, $keyword);
}

$obj = new CSV("oscar.csv");
print "----------------------Show header----------------------------------".PHP_EOL;
$obj->showHeader();
print "---------------------Get Header----------------------------------".PHP_EOL;
print_r($obj->getHeader());
print "----------------------searchItemByKey----------------------------------".PHP_EOL;
print_r($obj->searchItemByKey("Age1", 50));
print "----------------------showLine----------------------------------".PHP_EOL;
print $obj->showLine(1);
print "----------------------showLine----------------------------------".PHP_EOL;
print $obj->showLine();
